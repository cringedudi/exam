import os, re, sqlite3
from datetime import datetime
from flask import Flask, render_template, request, redirect, session, flash
from werkzeug.security import generate_password_hash, check_password_hash

# ---------- 1. НАСТРОЙКИ (меняются от варианта к варианту) ----------
ADMIN, ADMIN_PW = 'Conf2027', 'Demo77'
STATUSES = ['Новая', 'Мероприятие назначено', 'Завершено']
PAYMENTS = ['При очном посещении', 'Перевод по СБП']
ROOMS = ['Аудитория', 'Коворкинг', 'Кинозал']

app = Flask(__name__)
app.secret_key = 'x'
app.jinja_env.globals.update(STATUSES=STATUSES)
BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'app.db')

# ---------- 2. БАЗА: одна функция на все запросы ----------
def q(sql, args=(), one=False):
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    rows = con.execute(sql, args).fetchall()
    con.commit()
    con.close()
    return (rows[0] if rows else None) if one else rows


sqlite3.connect(DB).executescript(open(os.path.join(BASE, 'schema.sql'), encoding='utf-8').read())

# ---------- 3. ЗАЩИТА СТРАНИЦ ----------
@app.before_request
def guard():
    p = request.path
    if p == '/' or p.startswith(('/login', '/register', '/static')):
        return
    if not session.get('admin' if p.startswith('/admin') else 'uid'):
        return redirect('/login')


@app.route('/')
def index():
    return redirect('/login')

# ---------- 4. РЕГИСТРАЦИЯ ----------
RULES = [  # (поле, регулярка, сообщение)
    ('login', r'[A-Za-z0-9]{6,}', 'Логин: латиница и цифры, от 6 символов'),
    ('password', r'.{8,}', 'Пароль: от 8 символов'),
    ('fio', r'[А-Яа-яЁё ]+', 'ФИО: кириллица и пробелы'),
    ('phone', r'8\(\d{3}\)\d{3}-\d{2}-\d{2}', 'Телефон: 8(XXX)XXX-XX-XX'),
    ('email', r'\S+@\S+\.\S+', 'Некорректный e-mail'),
]


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        f = request.form
        errs = [msg for key, rx, msg in RULES if not re.fullmatch(rx, f.get(key, ''))]
        if not errs:
            try:
                q('INSERT INTO users (login, pwd, fio, phone, email) VALUES (?,?,?,?,?)',
                  (f['login'], generate_password_hash(f['password']), f['fio'], f['phone'], f['email']))
                flash('Регистрация успешна, войдите')
                return redirect('/login')
            except sqlite3.IntegrityError:
                errs = ['Такой логин уже занят']
        for e in errs: flash(e)
    return render_template('register.html', form=request.form)

# ---------- 5. ВХОД / ВЫХОД ----------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        l, p = request.form['login'], request.form['password']
        u = q('SELECT * FROM users WHERE login=?', (l,), one=True)
        if (l, p) == (ADMIN, ADMIN_PW):
            session.clear(); session['admin'] = 1
            return redirect('/admin')
        if not u: flash('Пользователь не найден')
        elif not check_password_hash(u['pwd'], p): flash('Неверный пароль')
        else:
            session.clear(); session['uid'] = u['id']
            return redirect('/requests')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

# ---------- 6. ЗАЯВКИ: список, создание/изменение, удаление, отзыв ----------
@app.route('/requests')
def my_requests():
    rows = q('SELECT * FROM requests WHERE user_id=? ORDER BY id DESC', (session['uid'],))
    return render_template('list.html', rows=rows)


def ok_date(s):
    for f in ('%d.%m.%Y', '%Y-%m-%d'):
        try: return bool(datetime.strptime(s, f))
        except ValueError: pass


@app.route('/new', methods=['GET', 'POST'])
@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def form(id=None):
    r = q('SELECT * FROM requests WHERE id=? AND user_id=?', (id, session['uid']), one=True)
    if id and not r:
        return redirect('/requests')
    if request.method == 'POST':
        room, date, pay = request.form['room'].strip(), request.form['date'].strip(), request.form['payment']
        if not room or not ok_date(date) or pay not in PAYMENTS:
            flash('Заполните все поля, дата в формате ДД.ММ.ГГГГ')
        else:
            if r: q('UPDATE requests SET room=?, date=?, payment=? WHERE id=?', (room, date, pay, id))
            else: q('INSERT INTO requests (user_id, room, date, payment, status) VALUES (?,?,?,?,?)',
                    (session['uid'], room, date, pay, STATUSES[0]))
            return redirect('/requests')
    v = request.form if request.method == 'POST' else (dict(r) if r else {})
    return render_template('new.html', v=v, r=r, rooms=ROOMS, payments=PAYMENTS)


@app.route('/delete/<int:id>', methods=['POST'])
def delete(id):
    q('DELETE FROM requests WHERE id=? AND user_id=? AND status=?', (id, session['uid'], STATUSES[0]))
    return redirect('/requests')


@app.route('/review/<int:id>', methods=['POST'])
def review(id):  # отзыв только после «Завершено»
    q('UPDATE requests SET review=? WHERE id=? AND user_id=? AND status=?',
      (request.form['review'].strip(), id, session['uid'], STATUSES[-1]))
    return redirect('/requests')

# ---------- 7. АДМИНКА ----------
@app.route('/admin')
def admin():
    st = request.args.get('status', '')
    if st not in STATUSES: st = ''
    rows = q('SELECT r.*, u.fio FROM requests r JOIN users u ON u.id=r.user_id '
             'WHERE ?="" OR r.status=? ORDER BY r.id DESC', (st, st))
    return render_template('admin.html', rows=rows, st=st)


@app.route('/admin/status/<int:id>', methods=['POST'])
def set_status(id):
    if request.form['status'] in STATUSES:
        q('UPDATE requests SET status=? WHERE id=?', (request.form['status'], id))
    return redirect('/admin')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)